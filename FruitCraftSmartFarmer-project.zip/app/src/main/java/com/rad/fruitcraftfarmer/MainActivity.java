package com.rad.fruitcraftfarmer;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final SharedPreferences sp = getSharedPreferences("farmer", MODE_PRIVATE);

        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(40, 70, 40, 40);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sv.addView(root);

        TextView help = new TextView(this);
        help.setTextSize(16);
        help.setText(
            "Fruit Craft Smart Farmer\n\n"
            + "مراحل راه‌اندازی:\n"
            + "۱) دکمه پایین را بزن و در لیست، «Fruit Craft Smart Farmer» را پیدا و روشن کن.\n"
            + "۲) بازی را باز کن. پنل کوچک START / STOP / POINTS روی صفحه می‌آید.\n"
            + "۳) یک‌بار POINTS را بزن و طبق متن بالای صفحه، روی ۵ دکمه بازی بزن "
            + "(کارت، Attack، ورود به معدن، جمع‌آوری طلا، بستن معدن).\n"
            + "۴) START را بزن. با STOP فوراً متوقف می‌شود.\n\n"
            + "نکته: ربات هر ۱۳ بازی خودش را متوقف می‌کند و هشدار می‌دهد تا اگر سؤال یا "
            + "تأیید هویتی آمده باشد، خودت جواب بدهی و بعد دوباره START بزنی.");
        root.addView(help);

        Button openAcc = new Button(this);
        openAcc.setText("باز کردن تنظیمات دسترسی‌پذیری");
        openAcc.setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(openAcc);

        TextView lbl = new TextView(this);
        lbl.setTextSize(16);
        lbl.setPadding(0, 40, 0, 0);
        lbl.setText("مدت انتظار برای تمام شدن هر بازی (ثانیه):");
        root.addView(lbl);

        final EditText wait = new EditText(this);
        wait.setInputType(InputType.TYPE_CLASS_NUMBER);
        wait.setText(String.valueOf(sp.getInt("wait", 45)));
        root.addView(wait);

        Button save = new Button(this);
        save.setText("ذخیره");
        save.setOnClickListener(v -> {
            int s = 45;
            try {
                s = Integer.parseInt(wait.getText().toString().trim());
            } catch (Exception ignored) {
            }
            if (s < 5) s = 5;
            if (s > 1200) s = 1200;
            sp.edit().putInt("wait", s).apply();
            wait.setText(String.valueOf(s));
            Toast.makeText(this, "ذخیره شد", Toast.LENGTH_SHORT).show();
        });
        root.addView(save);

        setContentView(sv);
    }
}
