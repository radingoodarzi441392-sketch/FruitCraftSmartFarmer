package com.rad.fruitcraftfarmer;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

public class BotService extends AccessibilityService {

    private static final long MINE_INTERVAL_MS = 48L * 60L * 1000L;
    private static final int CHECK_EVERY_GAMES = 13;

    private static final String[] KEYS = {"card", "attack", "mine", "collect", "close"};
    private static final String[] LABELS = {
        "کارتی که باید انتخاب شود",
        "دکمه Attack",
        "دکمه ورود به معدن",
        "دکمه جمع‌آوری طلا",
        "دکمه بستن / برگشت از معدن"
    };

    private SharedPreferences prefs;
    private WindowManager wm;
    private LinearLayout panel;
    private TextView statusView;
    private WindowManager.LayoutParams panelLp;
    private View calibView;

    private final Handler bot = new Handler(Looper.getMainLooper());
    private final Handler ui = new Handler(Looper.getMainLooper());

    private boolean running = false;
    private String gamePkg = null;
    private int misses = 0;
    private int totalGames = 0;
    private int sinceCheck = 0;
    private long lastMine = 0;
    private long runStart = 0;
    private long accumMs = 0;
    private String note = "آماده";

    // ---------------- lifecycle ----------------

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        prefs = getSharedPreferences("farmer", MODE_PRIVATE);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        buildPanel();
        ui.post(ticker);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // نیازی به پردازش رویداد نیست؛ کنترل پکیج در حلقه اصلی انجام می‌شود.
    }

    @Override
    public void onInterrupt() {
        stopBot("سرویس قطع شد", false);
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        cleanup();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        cleanup();
        super.onDestroy();
    }

    private void cleanup() {
        running = false;
        bot.removeCallbacksAndMessages(null);
        ui.removeCallbacksAndMessages(null);
        removeCalib();
        try {
            if (panel != null && wm != null) wm.removeView(panel);
        } catch (Exception ignored) {
        }
        panel = null;
    }

    // ---------------- floating panel ----------------

    private Button mkBtn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(11);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        return b;
    }

    private void buildPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(Color.argb(210, 20, 20, 20));
        panel.setPadding(14, 14, 14, 14);

        statusView = new TextView(this);
        statusView.setTextColor(Color.WHITE);
        statusView.setTextSize(11);
        statusView.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        panel.addView(statusView);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button start = mkBtn("START");
        Button stop = mkBtn("STOP");
        Button pts = mkBtn("POINTS");
        row.addView(start);
        row.addView(stop);
        row.addView(pts);
        panel.addView(row);

        start.setOnClickListener(v -> startBot());
        stop.setOnClickListener(v -> stopBot("متوقف شد (STOP)", false));
        pts.setOnClickListener(v -> startCalibration());

        panelLp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.START;
        panelLp.x = 0;
        panelLp.y = 120;

        // کشیدن پنل با انگشت روی متن وضعیت
        statusView.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float touchX, touchY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = panelLp.x;
                        startY = panelLp.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelLp.x = startX + (int) (e.getRawX() - touchX);
                        panelLp.y = startY + (int) (e.getRawY() - touchY);
                        try {
                            wm.updateViewLayout(panel, panelLp);
                        } catch (Exception ignored) {
                        }
                        return true;
                    default:
                        return true;
                }
            }
        });

        wm.addView(panel, panelLp);
        updateStatus();
    }

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            updateStatus();
            ui.postDelayed(this, 1000);
        }
    };

    private void updateStatus() {
        if (statusView == null) return;
        long now = System.currentTimeMillis();
        long ms = accumMs + (running ? now - runStart : 0);
        String t = String.format(Locale.US, "%02d:%02d:%02d",
            ms / 3600000, (ms / 60000) % 60, (ms / 1000) % 60);
        String mine = "-";
        if (running && lastMine > 0) {
            long left = Math.max(0, MINE_INTERVAL_MS - (now - lastMine));
            mine = String.format(Locale.US, "%02d:%02d", left / 60000, (left / 1000) % 60);
        }
        statusView.setText("بازی‌ها: " + totalGames
            + "\nزمان: " + t
            + "\nمعدن بعدی: " + mine
            + "\n" + note);
    }

    // ---------------- bot control ----------------

    private void startBot() {
        if (running) return;
        for (String k : KEYS) {
            if (prefs.getInt("x_" + k, -1) < 0) {
                note = "اول POINTS را بزن و نقاط را ثبت کن";
                return;
            }
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        CharSequence p = (root == null) ? null : root.getPackageName();
        if (p == null) {
            note = "بازی پیدا نشد؛ اول بازی را باز کن";
            return;
        }
        String pkg = p.toString();
        if (pkg.equals(getPackageName()) || pkg.contains("launcher")
            || pkg.equals("com.android.systemui")) {
            note = "اول بازی را باز کن، بعد START بزن";
            return;
        }
        gamePkg = pkg;
        misses = 0;
        sinceCheck = 0;
        running = true;
        runStart = System.currentTimeMillis();
        if (lastMine == 0) lastMine = runStart;
        note = "در حال اجرا";
        bot.removeCallbacksAndMessages(null);
        bot.post(cycle);
    }

    private void stopBot(String reason, boolean alert) {
        if (running) {
            accumMs += System.currentTimeMillis() - runStart;
        }
        running = false;
        bot.removeCallbacksAndMessages(null);
        note = reason;
        if (alert) alertUser();
        updateStatus();
    }

    private boolean gameInFront() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            misses++;
            return misses < 3;
        }
        misses = 0;
        CharSequence p = root.getPackageName();
        return p != null && p.toString().equals(gamePkg);
    }

    private void alertUser() {
        try {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v != null) {
                v.vibrate(VibrationEffect.createWaveform(
                    new long[]{0, 400, 200, 400, 200, 400}, -1));
            }
        } catch (Exception ignored) {
        }
        try {
            new ToneGenerator(AudioManager.STREAM_ALARM, 100)
                .startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 1500);
        } catch (Exception ignored) {
        }
    }

    // ---------------- main loop ----------------

    private final Runnable cycle = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            if (!gameInFront()) {
                stopBot("صفحه ناشناخته یا خروج از بازی؛ ربات متوقف شد", true);
                return;
            }
            if (System.currentTimeMillis() - lastMine >= MINE_INTERVAL_MS) {
                note = "جمع‌آوری طلای معدن...";
                runTaps(new String[]{"mine", "collect", "close"}, 0, () -> {
                    lastMine = System.currentTimeMillis();
                    note = "در حال اجرا";
                    bot.postDelayed(cycle, 1500);
                });
                return;
            }
            note = "انتخاب کارت";
            if (!tap("card")) return;
            bot.postDelayed(attackStep, 1500);
        }
    };

    private final Runnable attackStep = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            note = "Attack و انتظار...";
            if (!tap("attack")) return;
            int wait = prefs.getInt("wait", 45);
            bot.postDelayed(afterBattle, wait * 1000L);
        }
    };

    private final Runnable afterBattle = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            totalGames++;
            sinceCheck++;
            if (sinceCheck >= CHECK_EVERY_GAMES) {
                sinceCheck = 0;
                stopBot("۱۳ بازی تمام شد. اگر سؤال یا تأیید هویت آمده، خودت جواب بده و دوباره START بزن", true);
                return;
            }
            bot.postDelayed(cycle, 1500);
        }
    };

    private interface Done {
        void run();
    }

    private void runTaps(final String[] keys, final int i, final Done done) {
        if (!running) return;
        if (i >= keys.length) {
            done.run();
            return;
        }
        if (!tap(keys[i])) return;
        bot.postDelayed(() -> runTaps(keys, i + 1, done), 2000);
    }

    private boolean tap(String key) {
        int x = prefs.getInt("x_" + key, -1);
        int y = prefs.getInt("y_" + key, -1);
        if (x < 0 || y < 0) {
            stopBot("نقطه ثبت نشده است", true);
            return false;
        }
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription g = new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(p, 0, 80))
            .build();
        boolean ok = dispatchGesture(g, null, null);
        if (!ok) {
            stopBot("ضربه زدن ممکن نشد؛ ربات متوقف شد", true);
        }
        return ok;
    }

    // ---------------- calibration ----------------

    private void startCalibration() {
        if (running) stopBot("متوقف شد برای ثبت نقاط", false);
        calibStep(0);
    }

    private void removeCalib() {
        try {
            if (calibView != null && wm != null) wm.removeView(calibView);
        } catch (Exception ignored) {
        }
        calibView = null;
    }

    private void calibStep(final int i) {
        removeCalib();
        if (i >= KEYS.length) {
            note = "نقاط ذخیره شد ✔";
            updateStatus();
            return;
        }
        TextView v = new TextView(this);
        v.setBackgroundColor(Color.argb(90, 0, 0, 0));
        v.setTextColor(Color.YELLOW);
        v.setTextSize(17);
        v.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        v.setPadding(20, 90, 20, 20);
        v.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        v.setText((i + 1) + " از " + KEYS.length + "\nروی این بزن: " + LABELS[i]);
        v.setOnTouchListener((view, e) -> {
            if (e.getAction() == MotionEvent.ACTION_UP) {
                final int x = (int) e.getRawX();
                final int y = (int) e.getRawY();
                prefs.edit().putInt("x_" + KEYS[i], x).putInt("y_" + KEYS[i], y).apply();
                ui.post(() -> calibStep(i + 1));
            }
            return true;
        });
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.TRANSLUCENT);
        wm.addView(v, lp);
        calibView = v;
    }
}
